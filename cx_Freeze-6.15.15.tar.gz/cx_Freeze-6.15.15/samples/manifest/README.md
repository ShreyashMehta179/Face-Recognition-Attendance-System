# Icon sample

Creates an executable to demonstrate the use of manifest and uac_admin.


# Installation and requirements:

In a virtual environment, install by issuing the command:

```
pip install cx_Freeze
```

# Build the executable:

```
python setup.py build
```

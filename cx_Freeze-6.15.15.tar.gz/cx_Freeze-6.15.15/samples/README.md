# Samples

Here are samples to test cx_Freeze or to show how to use a package in cx_Freeze.

# Documentation

The official documentation is available
[here](https://cx-freeze.readthedocs.io).

# Installation

In a virtual environment, install by issuing the command:

```
pip install cx_Freeze --upgrade
```

from __future__ import annotations

print("importing pkg1.pkg2")

from .. import sub4  # noqa
from . import sub3  # noqa

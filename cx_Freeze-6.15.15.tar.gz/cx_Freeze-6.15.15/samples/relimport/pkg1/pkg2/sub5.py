from __future__ import annotations

print("importing pkg1.pkg2.sub5")

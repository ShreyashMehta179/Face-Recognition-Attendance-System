from __future__ import annotations

print("importing pkg1.pkg2.sub3")

from .. import sub6  # noqa
from . import sub5  # noqa

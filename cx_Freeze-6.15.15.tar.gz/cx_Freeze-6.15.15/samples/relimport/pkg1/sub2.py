from __future__ import annotations

print("importing pkg1.sub2")

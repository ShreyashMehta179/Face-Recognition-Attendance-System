from __future__ import annotations

import bcrypt

print("bcrypt gensalt", bcrypt.gensalt())

# Icon sample

Creates two executables and demonstrate the use a valid and an invalid icon.

# Installation and requirements:

In a virtual environment, install by issuing the command:

```
pip install cx_Freeze
```

# Build the executable:

```
python setup.py build
```
